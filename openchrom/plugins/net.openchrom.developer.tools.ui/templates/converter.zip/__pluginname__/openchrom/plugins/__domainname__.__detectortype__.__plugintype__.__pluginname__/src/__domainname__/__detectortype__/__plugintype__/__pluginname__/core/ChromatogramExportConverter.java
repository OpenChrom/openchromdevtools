__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.core;

import java.io.File;

import org.eclipse.chemclipse.converter.chromatogram.IChromatogramExportConverter;
import org.eclipse.chemclipse.converter.processing.chromatogram.ChromatogramExportConverterProcessingInfo;
import org.eclipse.chemclipse.converter.processing.chromatogram.IChromatogramExportConverterProcessingInfo;
import org.eclipse.chemclipse.__detectortype__.converter.chromatogram.AbstractChromatogram__detectorclass__ExportConverter;
import org.eclipse.chemclipse.__detectortype__.model.core.IChromatogram__detectorclass__;
import org.eclipse.core.runtime.IProgressMonitor;

public class ChromatogramExportConverter extends AbstractChromatogram__detectorclass__ExportConverter implements IChromatogramExportConverter {

	@Override
	public IChromatogramExportConverterProcessingInfo convert(File file, IChromatogram__detectorclass__ chromatogram, IProgressMonitor monitor) {

		IChromatogramExportConverterProcessingInfo processingInfo = new ChromatogramExportConverterProcessingInfo();
		return processingInfo;
	}
}

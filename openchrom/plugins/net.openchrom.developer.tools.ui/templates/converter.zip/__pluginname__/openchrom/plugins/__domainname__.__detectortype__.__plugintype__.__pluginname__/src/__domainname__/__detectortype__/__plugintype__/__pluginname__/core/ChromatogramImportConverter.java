__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.core;

import java.io.File;

import org.eclipse.chemclipse.converter.chromatogram.IChromatogramImportConverter;
import org.eclipse.chemclipse.converter.processing.chromatogram.ChromatogramOverviewImportConverterProcessingInfo;
import org.eclipse.chemclipse.converter.processing.chromatogram.IChromatogramOverviewImportConverterProcessingInfo;
import org.eclipse.chemclipse.converter.support.IConstants;
import org.eclipse.chemclipse.logging.core.Logger;
import org.eclipse.chemclipse.model.core.IChromatogramOverview;
import org.eclipse.chemclipse.processing.core.IProcessingInfo;
import org.eclipse.chemclipse.__detectortype__.converter.chromatogram.AbstractChromatogram__detectorclass__ImportConverter;
import org.eclipse.chemclipse.__detectortype__.converter.io.IChromatogram__detectorclass__Reader;
import org.eclipse.chemclipse.__detectortype__.converter.processing.chromatogram.Chromatogram__detectorclass__ImportConverterProcessingInfo;
import org.eclipse.chemclipse.__detectortype__.converter.processing.chromatogram.IChromatogram__detectorclass__ImportConverterProcessingInfo;
import org.eclipse.chemclipse.__detectortype__.model.core.IChromatogram__detectorclass__;
import org.eclipse.core.runtime.IProgressMonitor;

import __domainname__.__detectortype__.__plugintype__.__pluginname__.io.ChromatogramReader;
import __domainname__.__detectortype__.__plugintype__.__pluginname__.io.SpecificationValidator;

public class ChromatogramImportConverter extends AbstractChromatogram__detectorclass__ImportConverter implements IChromatogramImportConverter {

	private static final Logger logger = Logger.getLogger(ChromatogramImportConverter.class);
	private static final String DESCRIPTION = "__label__";

	@Override
	public IChromatogram__detectorclass__ImportConverterProcessingInfo convert(File file, IProgressMonitor monitor) {

		IChromatogram__detectorclass__ImportConverterProcessingInfo processingInfo = new Chromatogram__detectorclass__ImportConverterProcessingInfo();
		/*
		 * Validate the file.
		 */
		IProcessingInfo processingInfoValidate = super.validate(file);
		if(processingInfoValidate.hasErrorMessages()) {
			processingInfo.addMessages(processingInfoValidate);
		} else {
			/*
			 * Read the chromatogram.
			 */
			file = SpecificationValidator.validateSpecification(file);
			IChromatogram__detectorclass__Reader reader = new ChromatogramReader();
			monitor.subTask(IConstants.IMPORT_CHROMATOGRAM);
			try {
				IChromatogram__detectorclass__ chromatogram = reader.read(file, monitor);
				processingInfo.setChromatogram(chromatogram);
			} catch(Exception e) {
				logger.warn(e);
				processingInfo.addErrorMessage(DESCRIPTION, "Something has definitely gone wrong with the file: " + file.getAbsolutePath());
			}
		}
		return processingInfo;
	}

	@Override
	public IChromatogramOverviewImportConverterProcessingInfo convertOverview(File file, IProgressMonitor monitor) {

		IChromatogramOverviewImportConverterProcessingInfo processingInfo = new ChromatogramOverviewImportConverterProcessingInfo();
		/*
		 * Validate the file.
		 */
		IProcessingInfo processingInfoValidate = super.validate(file);
		if(processingInfoValidate.hasErrorMessages()) {
			processingInfo.addMessages(processingInfoValidate);
		} else {
			/*
			 * Read the chromatogram overview.
			 */
			file = SpecificationValidator.validateSpecification(file);
			IChromatogram__detectorclass__Reader reader = new ChromatogramReader();
			monitor.subTask(IConstants.IMPORT_CHROMATOGRAM_OVERVIEW);
			try {
				IChromatogramOverview chromatogramOverview = reader.readOverview(file, monitor);
				processingInfo.setChromatogramOverview(chromatogramOverview);
			} catch(Exception e) {
				logger.warn(e);
				processingInfo.addErrorMessage(DESCRIPTION, "Something has definitely gone wrong with the file: " + file.getAbsolutePath());
			}
		}
		return processingInfo;
	}
}

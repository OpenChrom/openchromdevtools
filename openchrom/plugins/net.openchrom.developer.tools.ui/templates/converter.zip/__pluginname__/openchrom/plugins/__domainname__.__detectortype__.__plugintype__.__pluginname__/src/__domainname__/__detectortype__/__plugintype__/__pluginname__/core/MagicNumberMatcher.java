__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.core;

import java.io.File;

import org.eclipse.chemclipse.converter.core.AbstractMagicNumberMatcher;
import org.eclipse.chemclipse.converter.core.IMagicNumberMatcher;
import org.eclipse.chemclipse.model.core.IChromatogramOverview;
import org.eclipse.chemclipse.__detectortype__.converter.io.IChromatogram__detectorclass__Reader;
import org.eclipse.core.runtime.NullProgressMonitor;

import __domainname__.__detectortype__.__plugintype__.__pluginname__.io.ChromatogramReader;
import __domainname__.__detectortype__.__plugintype__.__pluginname__.io.SpecificationValidator;

public class MagicNumberMatcher extends AbstractMagicNumberMatcher implements IMagicNumberMatcher {

	@Override
	public boolean checkFileFormat(File file) {

		boolean isValidFormat = false;
		try {
			file = SpecificationValidator.validateSpecification(file);
			IChromatogram__detectorclass__Reader reader = new ChromatogramReader();
			IChromatogramOverview chromatogramOverview = reader.readOverview(file, new NullProgressMonitor());
			if(chromatogramOverview != null) {
				isValidFormat = true;
			}
		} catch(Exception e) {
			// Print no exception.
		}
		return isValidFormat;
	}
}

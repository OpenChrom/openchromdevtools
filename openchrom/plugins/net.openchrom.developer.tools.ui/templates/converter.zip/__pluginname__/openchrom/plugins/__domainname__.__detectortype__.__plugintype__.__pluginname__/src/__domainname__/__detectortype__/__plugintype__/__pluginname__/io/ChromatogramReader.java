__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.eclipse.chemclipse.converter.exceptions.FileIsEmptyException;
import org.eclipse.chemclipse.converter.exceptions.FileIsNotReadableException;
import org.eclipse.chemclipse.model.core.IChromatogramOverview;
import org.eclipse.chemclipse.__detectortype__.converter.io.AbstractChromatogram__detectorclass__Reader;
import org.eclipse.chemclipse.__detectortype__.model.core.IChromatogram__detectorclass__;
import org.eclipse.core.runtime.IProgressMonitor;

public class ChromatogramReader extends AbstractChromatogram__detectorclass__Reader {

	@Override
	public IChromatogram__detectorclass__ read(File file, IProgressMonitor monitor) throws FileNotFoundException, FileIsNotReadableException, FileIsEmptyException, IOException {

		System.out.println("Implement");
		return null;
	}

	@Override
	public IChromatogramOverview readOverview(File file, IProgressMonitor monitor) throws FileNotFoundException, FileIsNotReadableException, FileIsEmptyException, IOException {

		System.out.println("Implement");
		return null;
	}
}

__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.eclipse.chemclipse.converter.exceptions.FileIsNotWriteableException;
import org.eclipse.chemclipse.__detectortype__.converter.io.AbstractChromatogram__detectorclass__Writer;
import org.eclipse.chemclipse.__detectortype__.model.core.IChromatogram__detectorclass__;
import org.eclipse.core.runtime.IProgressMonitor;

public class ChromatogramWriter extends AbstractChromatogram__detectorclass__Writer {

	@Override
	public void writeChromatogram(File file, IChromatogram__detectorclass__ chromatogram, IProgressMonitor monitor) throws FileNotFoundException, FileIsNotWriteableException, IOException {

	}
}

__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.io;

import java.io.File;

public class SpecificationValidator {

	/**
	 * Use only static methods.
	 */
	private SpecificationValidator() {
	}

	public static File validateSpecification(File file) {

		if(file == null) {
			return null;
		}
		/*
		 * Validate
		 */
		File validFile;
		String path = file.getAbsolutePath().toUpperCase();
		if(file.isDirectory()) {
			validFile = new File(file.getAbsolutePath() + File.separator + "CHROMATOGRAM.__fileextension__");
		} else {
			if(path.endsWith(".")) {
				validFile = new File(file.getAbsolutePath() + "__fileextension__");
			} else if(!path.endsWith(".__fileextension__")) {
				validFile = new File(file.getAbsolutePath() + ".__fileextension__");
			} else {
				validFile = file;
			}
		}
		return validFile;
	}
}

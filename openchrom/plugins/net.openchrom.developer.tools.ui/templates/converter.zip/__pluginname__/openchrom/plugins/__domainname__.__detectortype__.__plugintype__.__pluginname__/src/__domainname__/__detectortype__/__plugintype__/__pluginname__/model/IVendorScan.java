__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.model;

import org.eclipse.chemclipse.__detectortype__.model.core.IScan__detectorclass__;

public interface IVendorScan extends IScan__detectorclass__ {
}

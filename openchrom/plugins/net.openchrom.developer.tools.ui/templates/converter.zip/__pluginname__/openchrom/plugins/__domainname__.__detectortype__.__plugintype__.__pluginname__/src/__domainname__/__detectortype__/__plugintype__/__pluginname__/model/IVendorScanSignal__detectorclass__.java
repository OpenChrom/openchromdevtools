__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.model;

import org.eclipse.chemclipse.__detectortype__.model.core.IScanSignal__detectorclass__;

public interface IVendorScanSignal__detectorclass__ extends IScanSignal__detectorclass__ {
}

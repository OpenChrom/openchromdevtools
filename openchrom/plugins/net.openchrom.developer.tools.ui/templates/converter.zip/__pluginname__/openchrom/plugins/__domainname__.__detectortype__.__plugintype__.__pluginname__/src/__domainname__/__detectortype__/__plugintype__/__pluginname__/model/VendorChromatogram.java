__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.model;

import org.eclipse.chemclipse.__detectortype__.model.core.AbstractChromatogram__detectorclass__;

public class VendorChromatogram extends AbstractChromatogram__detectorclass__ implements IVendorChromatogram {

	@Override
	public double getPeakIntegratedArea() {

		return 0;
	}
}

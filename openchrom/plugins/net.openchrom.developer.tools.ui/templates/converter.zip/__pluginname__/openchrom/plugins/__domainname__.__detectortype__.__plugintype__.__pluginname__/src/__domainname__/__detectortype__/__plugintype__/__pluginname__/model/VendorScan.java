__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.model;

import org.eclipse.chemclipse.__detectortype__.model.core.AbstractScan__detectorclass__;

public class VendorScan extends AbstractScan__detectorclass__ implements IVendorScan {

	/**
	 * Renew the serialVersionUID any time you have changed some fields or
	 * methods.
	 */
}

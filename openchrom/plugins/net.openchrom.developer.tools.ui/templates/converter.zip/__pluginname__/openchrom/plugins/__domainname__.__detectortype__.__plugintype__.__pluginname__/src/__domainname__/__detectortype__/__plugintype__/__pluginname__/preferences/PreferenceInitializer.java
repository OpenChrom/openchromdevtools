__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.preferences;

import org.eclipse.chemclipse.support.preferences.AbstractExtendedPreferenceInitializer;

public class PreferenceInitializer extends AbstractExtendedPreferenceInitializer {

	public PreferenceInitializer() {
		super(PreferenceSupplier.INSTANCE());
	}
}

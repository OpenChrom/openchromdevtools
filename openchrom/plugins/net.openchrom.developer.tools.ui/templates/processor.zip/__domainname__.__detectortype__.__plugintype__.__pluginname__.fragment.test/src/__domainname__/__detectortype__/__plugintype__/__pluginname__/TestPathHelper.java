/*******************************************************************************
 * Copyright (c) 2017 Lablicate GmbH.
 * 
 * All rights reserved.
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 * Dr. Philip Wenig - initial API and implementation
 *******************************************************************************/
package __domainname__.__detectortype__.__plugintype__.__pluginname__;

import __domainname__.__detectortype__.__plugintype__.__pluginname__.PathResolver;

/**
 * THIS CLASS IS NOT SUITED FOR PRODUCTIVE USE!<br/>
 * IT IS A TESTCLASS!
 */
public class TestPathHelper extends PathResolver {

	/*
	 * IMPORT
	 */
	public static final String TESTFILE_IMPORT_1 = "testData/files/import/test.txt";
}

__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.ui.wizards;

public interface IProcessorWizardElements {

	String getDescription();

	void setDescription(String evaluationDescription);
}

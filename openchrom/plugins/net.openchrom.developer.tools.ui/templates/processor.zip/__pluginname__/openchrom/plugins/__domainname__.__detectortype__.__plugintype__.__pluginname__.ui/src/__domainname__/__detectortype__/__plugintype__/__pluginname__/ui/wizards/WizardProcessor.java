__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.ui.wizards;

import java.util.Date;

import org.eclipse.chemclipse.support.ui.wizards.AbstractFileWizard;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import __domainname__.__detectortype__.__plugintype__.__pluginname__.core.Processor;

public class WizardProcessor extends AbstractFileWizard {

	private IProcessorWizardElements wizardElements = new ProcessorWizardElements();
	private PageDescription pageDescription;

	public WizardProcessor() {
		super("__pluginname__" + new Date().getTime(), Processor.PROCESSOR_FILE_EXTENSION);
	}

	@Override
	public void addPages() {

		super.addPages();
		/*
		 * Pages must implement IExtendedWizardPage / extend AbstractExtendedWizardPage
		 */
		pageDescription = new PageDescription(wizardElements);
		//
		addPage(pageDescription);
	}

	@Override
	public boolean canFinish() {

		boolean canFinish = pageDescription.canFinish();
		return canFinish;
	}

	@Override
	public void doFinish(IProgressMonitor monitor) throws CoreException {

		monitor.beginTask("__pluginname__", IProgressMonitor.UNKNOWN);
		final IFile file = super.prepareProject(monitor);
		// TODO Write file
		/*
		 * Refresh
		 */
		super.refreshWorkspace(monitor);
		super.runOpenEditor(file, monitor);
	}
}

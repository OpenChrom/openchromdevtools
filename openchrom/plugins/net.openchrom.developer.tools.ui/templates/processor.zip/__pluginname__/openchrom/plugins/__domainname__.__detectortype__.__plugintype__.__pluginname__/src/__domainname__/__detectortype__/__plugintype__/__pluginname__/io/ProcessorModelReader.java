__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.io;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.eclipse.core.runtime.IProgressMonitor;

import __domainname__.__detectortype__.__plugintype__.__pluginname__.model.ProcessorModel;

public class ProcessorModelReader {

	public ProcessorModel read(File file, IProgressMonitor monitor) throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(new Class[]{ProcessorModel.class});
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		return (ProcessorModel)unmarshaller.unmarshal(file);
	}
}

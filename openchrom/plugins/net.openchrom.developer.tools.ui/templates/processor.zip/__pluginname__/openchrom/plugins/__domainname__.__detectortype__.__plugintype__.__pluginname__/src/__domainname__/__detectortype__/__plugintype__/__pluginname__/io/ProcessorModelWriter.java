__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.io;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.eclipse.core.runtime.IProgressMonitor;

import __domainname__.__detectortype__.__plugintype__.__pluginname__.model.ProcessorModel;

public class ProcessorModelWriter {

	public void write(File file, ProcessorModel processorModel, IProgressMonitor monitor) throws JAXBException {

		JAXBContext jaxbContext = JAXBContext.newInstance(new Class[]{ProcessorModel.class});
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(processorModel, file);
	}
}

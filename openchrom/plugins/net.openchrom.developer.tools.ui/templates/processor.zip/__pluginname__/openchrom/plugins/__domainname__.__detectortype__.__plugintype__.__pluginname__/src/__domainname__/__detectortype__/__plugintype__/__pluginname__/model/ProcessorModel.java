__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name = "__pluginname__")
public class ProcessorModel {

	@XmlElement(name = "ChromatogramName")
	private String chromatogramName;
	@XmlElement(name = "ChromatogramPath")
	private String chromatogramPath;
	@XmlElement(name = "Notes")
	private String notes;

	@XmlTransient
	public String getChromatogramName() {

		return chromatogramName;
	}

	public void setChromatogramName(String chromatogramName) {

		this.chromatogramName = chromatogramName;
	}

	@XmlTransient
	public String getChromatogramPath() {

		return chromatogramPath;
	}

	public void setChromatogramPath(String chromatogramPath) {

		this.chromatogramPath = chromatogramPath;
	}

	@XmlTransient
	public String getNotes() {

		return notes;
	}

	public void setNotes(String notes) {

		this.notes = notes;
	}
}

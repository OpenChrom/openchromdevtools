__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.ui.handlers;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;

import __domainname__.__detectortype__.__plugintype__.__pluginname__.ui.wizards.WizardProcessor;

public class ProcessorWizardHandler {

	@Execute
	public void execute() {

		WizardDialog wizardDialog = new WizardDialog(Display.getCurrent().getActiveShell(), new WizardProcessor());
		wizardDialog.open();
	}
}

__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.ui.wizards;

import org.eclipse.chemclipse.support.ui.wizards.ChromatogramWizardElements;

public class ProcessorWizardElements extends ChromatogramWizardElements implements IProcessorWizardElements {

	private String description = ""; // Could be ""

	@Override
	public String getDescription() {

		return description;
	}

	@Override
	public void setDescription(String description) {

		this.description = description;
	}
}

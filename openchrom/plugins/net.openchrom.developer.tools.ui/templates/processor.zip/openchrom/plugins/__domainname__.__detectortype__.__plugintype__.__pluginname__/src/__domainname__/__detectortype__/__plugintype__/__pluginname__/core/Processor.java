__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.core;

public class Processor {

	public static final String PROCESSOR_FILE_EXTENSION = "__fileextension__";
}

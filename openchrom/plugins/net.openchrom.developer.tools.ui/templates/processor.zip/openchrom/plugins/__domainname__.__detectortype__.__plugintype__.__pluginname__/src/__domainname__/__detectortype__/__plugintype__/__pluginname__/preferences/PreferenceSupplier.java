__license__
package __domainname__.__detectortype__.__plugintype__.__pluginname__.preferences;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.chemclipse.support.preferences.IPreferenceSupplier;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IScopeContext;
import org.eclipse.core.runtime.preferences.InstanceScope;

import __domainname__.__detectortype__.__plugintype__.__pluginname__.Activator;

public class PreferenceSupplier implements IPreferenceSupplier {

	public static final String P_MY_SETTING = "mySetting";
	public static final double DEF_MY_SETTING = 42.0d;
	public static final double MY_SETTING_MIN = 1.0d;
	public static final double MY_SETTING_MAX = 100.0d;
	//
	private static IPreferenceSupplier preferenceSupplier;

	public static IPreferenceSupplier INSTANCE() {

		if(preferenceSupplier == null) {
			preferenceSupplier = new PreferenceSupplier();
		}
		return preferenceSupplier;
	}

	@Override
	public IScopeContext getScopeContext() {

		return InstanceScope.INSTANCE;
	}

	@Override
	public String getPreferenceNode() {

		return Activator.getContext().getBundle().getSymbolicName();
	}

	@Override
	public Map<String, String> getDefaultValues() {

		Map<String, String> defaultValues = new HashMap<String, String>();
		defaultValues.put(P_MY_SETTING, Double.toString(DEF_MY_SETTING));
		return defaultValues;
	}

	@Override
	public IEclipsePreferences getPreferences() {

		return getScopeContext().getNode(getPreferenceNode());
	}
}
